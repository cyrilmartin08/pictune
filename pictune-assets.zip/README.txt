Sample music asset placeholders for the Silent Composer project.
Replace these .mp3 files with real royalty-free audio clips.
happy_lofi.mp3: Happy lo-fi beat
sad_piano.mp3: Sad solo piano
calm_ambient.mp3: Calm ambient pad
intense_beats.mp3: Intense electronic beat
dreamy_melody.mp3: Dreamy melodic tune
